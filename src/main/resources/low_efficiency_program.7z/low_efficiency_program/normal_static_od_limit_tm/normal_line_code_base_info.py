import configparser

import numpy as np
import pandas as pd
from datetime import datetime
from datetime import timedelta
import pymysql
import sqlalchemy
from sqlalchemy import create_engine
import pickle
import re
import os

conf = configparser.ConfigParser()
root_dir = os.getcwd()  # 获取当前文件所在目录的上一级目录，即项目所在目录E:\Crawler
configpath = os.path.join(root_dir, 'config_data', "low_efficiency_config.ini")
conf.read(configpath)
product_type_trans = eval(conf.get("product_type_map", "product_type_trans"))

bd_city_path = os.path.join(root_dir, 'config_data', 'area2city.pkl')
with open(bd_city_path, 'rb') as f:
    bd_city = pickle.load(f)

# 构造 业务区:城市 kv值对
area_code = bd_city['area_code'].unique()
area_city = {}
for ac in area_code:
    city = ','.join(bd_city[bd_city.area_code == ac].city_code.values)
    area_city[ac] = city


def area_to_city(area_str):
    cargo_area_list = [area for area in area_str.strip().split(',') if re.match(r'\d+Y$', area)]
    temp_list = [area_city[area] for area in cargo_area_list]
    res = ','.join(temp_list)
    return res


def hub_to_city(hub_str):
    hub_list = [hub for hub in hub_str.strip().split(',') if re.match(r'\d+[A-Z]+', hub)]
    city_list = [re.match(r'\d+', hub).group() for hub in hub_list]
    city_set = list(set(city_list))

    return ','.join(city_set)


# 配载中城市信息去重
def unique_city(row):
    city1 = row['cargo_city'].split(',')
    city2 = row['area_city'].split(',')
    city3 = row['hub_city'].split(',')

    city1.extend(city2)
    city1.extend(city3)

    city_unique = list(set(city1))
    city_unique = [city for city in city_unique if city != '']
    return ','.join(city_unique)


def trans_product(cargo_product):
    temp_list = list(set([product_type_trans[pt] for pt in cargo_product.strip().split(',') if pt != '']))
    res = ','.join(temp_list)
    return res


def find_max_vehicle(grp):
    vehicle_num = grp.vehicle_num.values
    vehicle_max = vehicle_num.max()
    fliter_grp = [1 if num == vehicle_max else 0 for num in vehicle_num]
    grp['max_vehicle'] = fliter_grp
    return grp


def find_max_calc_time(grp):
    calc_time = grp.arrive_send_tm.values
    tm_max = calc_time.max()
    fliter_grp = [1 if tm == tm_max else 0 for tm in calc_time]
    grp['max_arrive_send_tm'] = fliter_grp
    return grp


def calc_time_apply(row):
    delt = datetime.strptime(row.plan_arrive_tm, '%Y-%m-%d %H:%M:%S') - datetime.strptime(row.plan_send_tm,
                                                                                          '%Y-%m-%d %H:%M:%S')
    delt = delt.total_seconds()
    return delt


# 车辆到达至班次的结束的时间
def arr_batch_lat(row):
    arr = row.plan_arrive_tm.split(' ')[1]
    if row['batch_lat_tm'] == '0':
        return 0
    lat = ':'.join([row['batch_lat_tm'][0:2], row['batch_lat_tm'][2:4], '00'])
    consum = datetime.strptime(lat, '%H:%M:%S') - datetime.strptime(arr, '%H:%M:%S')
    if consum.total_seconds() < 0:
        consum = consum + timedelta(1)  # 跨日，则加一天
    consum = consum.total_seconds() / 60
    return consum


def read_query_line(conn_pymysql, goal_date):
    # 读取数据
    sql_line = "SELECT * FROM `line_info_low_efficiency` where trans_capacity_type in (3, 4, 5)"
    sql_batch = 'SElECT * FROM `dw_batch_low_efficiency`'
    #     sql_line = "SELECT * FROM `line_info_low_efficiency` where line_require_date >= '{0} 00:00:00' and line_require_date <= '{1} 00:00:00'".format(goal_date, goal_date_7)
    #     sql_batch = "SElECT * FROM `dw_batch_low_efficiency` where version_dt >= '{0}' and version_dt <= '{1}'".format(goal_date, goal_date_7)
    df_batch = pd.read_sql(sql=sql_batch, con=conn_pymysql)  # 读取班次信息
    move_route = pd.read_sql(sql=sql_line, con=conn_pymysql)  # 读取线路编码配置信息

    # 处理信息编码信息
    move_route = move_route[
        ~((move_route.plan_arrive_tm.isnull()) | (move_route.plan_send_tm.isnull()) | (
            move_route.lastest_arrive_tm.isnull()))]  # 去除计划发车到达为空值的记录
    move_route = move_route[~((move_route.send_zone_code.isnull()) | (move_route.arrive_zone_code.isnull()))]
    # 将配载信息全为空的删除掉
    move_route = move_route[
        ~(move_route.cargo_area.isnull() & move_route.cargo_city.isnull() & move_route.cargo_code.isnull())]
    move_route = move_route[
        ~(move_route.route_code.isnull())]

    # 筛选工作日的线路配置表
    move_route['weekday'] = pd.to_datetime(move_route['line_require_date'], format='%Y-%m-%d %H:%M:%S')
    move_route['weekday'] = move_route['weekday'].dt.weekday
    move_route = move_route[move_route['weekday'].isin([1, 2, 3, 4, 5])]

    idx1 = move_route.groupby(['line_code', 'send_zone_code', 'arrive_zone_code'])['vehicle_num'].transform(max)
    move_route = move_route[move_route['vehicle_num'] == idx1]  # 筛选最大资源数的线路编码

    move_route['arrive_send_tm'] = move_route.apply(calc_time_apply, axis=1)
    idx2 = move_route.groupby(['line_code', 'send_zone_code', 'arrive_zone_code'])['arrive_send_tm'].transform(max)
    move_route = move_route[move_route['arrive_send_tm'] == idx2]  # 在资源数相同时，筛选耗时最长的，一般针对散航

    values = {'cargo_area': '', 'cargo_city': '', 'cargo_code': ''}
    move_route = move_route.fillna(value=values)  # 对null值填空

    # 将配置网点信息全部转换为城市
    move_route['area_city'] = move_route['cargo_area'].apply(area_to_city)
    move_route['hub_city'] = move_route['cargo_code'].apply(hub_to_city)
    move_route['total_city'] = move_route.apply(unique_city, axis=1)
    # 转换产品
    move_route['product'] = move_route['route_code'].apply(trans_product)

    move_route = move_route.drop_duplicates(
        ['line_code', 'send_zone_code', 'arrive_zone_code', 'total_city', 'product'])

    # 班次信息处理， 为线路信息添加最晚到车时间
    df_batch = df_batch[(df_batch.work_day.str.contains('234')) & (df_batch.is_delete == '0') &
                        (df_batch.expire_date > (datetime.now() - timedelta(7)).strftime(format='%Y-%m-%d %H:%M:%S'))]
    df_batch = df_batch.drop_duplicates('batch_code')  # 保留一条班次信息
    df_batch = df_batch[['hub_name', 'batch_code', 'latest_arrive_time', 'disperse_tag', 'distribution_type']]
    df_batch.columns = ['hub_name', 'arrive_batch', 'batch_lat_tm', 'disperse_tag', 'distribution_type']
    df_batch['batch_start_tm'] = df_batch['arrive_batch'].str[-4:]
    df_batch = df_batch.sort_values(['hub_name', 'batch_lat_tm'])  # 按网点和班次始发时间排序
    df_batch_san = df_batch[
        (df_batch.distribution_type == 3) | (df_batch.disperse_tag.isin(['S0', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6']))]
    df_batch_san = df_batch_san[['hub_name', 'arrive_batch', 'batch_lat_tm', 'batch_start_tm']]
    df_batch_san = df_batch_san[df_batch_san['batch_start_tm'].str.isdigit()]
    df_batch = df_batch[['hub_name', 'arrive_batch', 'batch_lat_tm']]

    # 保存班次信息后续计算始发目的相同时使用
    df_batch_path = os.path.join(root_dir, 'config_data', 'df_batch.pkl')
    df_batch_san_path = os.path.join(root_dir, 'config_data', 'df_batch_san.pkl')
    with open(df_batch_path, 'wb') as f:
        pickle.dump(df_batch, f)
    with open(df_batch_san_path, 'wb') as f:
        pickle.dump(df_batch_san, f)

    move_route = pd.merge(move_route, df_batch_san, how='left', on=['arrive_batch'])

    # 顺延散货班次
    san_batch = move_route[move_route['batch_lat_tm'].isnull()].arrive_batch.values
    re_sbatch = {}
    re_sbatch_name = {}
    for bt in san_batch:
        tmp_batch = df_batch_san[df_batch_san['hub_name'] == bt[:-4]]
        if len(tmp_batch) != 0:
            batch_name_tm = tmp_batch['arrive_batch'].values
            batch_start_tm = tmp_batch['batch_start_tm'].values
            batch_lat_tm = tmp_batch['batch_lat_tm'].values
            batch_label = bt[-4:]
            index = np.argmax(batch_start_tm > batch_label)
            re_sbatch[bt] = batch_lat_tm[index]
            re_sbatch_name[bt] = batch_name_tm[index]
        else:
            re_sbatch[bt] = '0'

    move_route['batch_lat_tm'].fillna(move_route['arrive_batch'], inplace=True)
    move_route['batch_lat_tm'].replace(re_sbatch, inplace=True)
    move_route['san_arrive_batch'] = move_route['arrive_batch']
    move_route['san_arrive_batch'].replace(re_sbatch_name, inplace=True)  # 添加散货班次
    # 集货中转场无法顺延散货班次，采用到达班次的最晚到车时间
    ji_batch = move_route[move_route['batch_lat_tm'] == '0'].arrive_batch.values
    re_jbatch = {}
    for bt in ji_batch:
        tmp_batch = df_batch[df_batch['arrive_batch'] == bt]
        if len(tmp_batch) != 0:
            batch_lat_tm = tmp_batch['batch_lat_tm'].values
            re_jbatch[bt] = batch_lat_tm[0]
        else:
            re_jbatch[bt] = '0'

    move_route.loc[move_route['batch_lat_tm'] == '0', 'batch_lat_tm'] = move_route['arrive_batch']
    move_route['batch_lat_tm'].replace(re_jbatch, inplace=True)
    move_route['add_batch_tm'] = move_route.apply(arr_batch_lat, axis=1)  # 提前计算到车时间至所在班次的最晚到时间，以备后用

    move_route = move_route[['line_code', 'line_require_date', 'send_zone_code', 'arrive_zone_code', 'arrive_batch',
                             'lastest_arrive_tm', 'plan_send_tm', 'plan_arrive_tm', 'total_city', 'product',
                             'san_arrive_batch', 'batch_lat_tm', 'add_batch_tm']]
    move_route['label'] = move_route['send_zone_code'] + '-' + move_route['line_code'] + '-' + move_route[
        'arrive_zone_code']

    return move_route


def generate_line_info(conn_pymysql, goal_date):
    move_route = read_query_line(conn_pymysql, goal_date)

    return move_route


# 重点城市对
def read_important_city(conn_pymysql):
    sql_2 = "select * from low_efficiency_important_city"
    important_city = pd.read_sql(sql=sql_2, con=conn_pymysql)
    important_city = set(important_city['important_city'].unique())

    return important_city
