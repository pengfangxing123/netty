import configparser
from multiprocessing import Process,Pool
import time
from datetime import datetime
from datetime import timedelta
import pandas as pd
import numpy as np
import pymysql
import sqlalchemy
from sqlalchemy import create_engine
import pickle
import re
import os
import sys

sys.path.append(os.path.abspath('.'))

from normal_static_od_limit_tm.normal_link_route import search_fast_route
from normal_static_od_limit_tm.normal_line_code_base_info import generate_line_info, read_important_city
from util.common_util import *

# DB_USER_read = 'ornp'
# DB_PASS_read = 'fiblGb6vuw'
# DB_HOST_read = 'ornp-m.dbsit.sfdc.com.cn'
# DB_PORT_read = '3306'
# DATABASE_read = 'ornp'



def get_important_city(conn):
    city = read_important_city(conn)
    return city

def normal_get_line_config(conn, line_date):
    line_info_name = 'line_info_' + line_date + '.pkl'
    line_info_all = line_cache_func(line_info_name, generate_line_info, conn_pymysql=conn, goal_date=line_date)

    # 为了减少查询量，简单的将不同产品分开
    # line_info_T1 = line_info_all[line_info_all['product'].str.contains('T1')].copy()
    # line_info_T4 = line_info_all[line_info_all['product'].str.contains('T4')].copy()
    # line_info_T6 = line_info_all[line_info_all['product'].str.contains('T6')].copy()
    # line_info_T8 = line_info_all[line_info_all['product'].str.contains('T8')].copy()
    # line_info_TX = line_info_all[line_info_all['product'].str.contains('TX')].copy()

    line_info_T1 = line_info_all
    line_info_T4 = line_info_all
    line_info_T6 = line_info_all
    line_info_T8 = line_info_all
    line_info_TX = line_info_all


    t1_send_zone = line_info_T1.send_zone_code.unique()
    t1_dict = {}
    for zone in t1_send_zone:
        t1_dict[zone] = line_info_T1[line_info_T1.send_zone_code == zone]

    t4_send_zone = line_info_T4.send_zone_code.unique()
    t4_dict = {}
    for zone in t4_send_zone:
        t4_dict[zone] = line_info_T4[line_info_T4.send_zone_code == zone]

    t6_send_zone = line_info_T6.send_zone_code.unique()
    t6_dict = {}
    for zone in t6_send_zone:
        t6_dict[zone] = line_info_T6[line_info_T6.send_zone_code == zone]

    t8_send_zone = line_info_T8.send_zone_code.unique()
    t8_dict = {}
    for zone in t8_send_zone:
        t8_dict[zone] = line_info_T8[line_info_T8.send_zone_code == zone]

    tx_send_zone = line_info_TX.send_zone_code.unique()
    tx_dict = {}
    for zone in tx_send_zone:
        tx_dict[zone] = line_info_TX[line_info_TX.send_zone_code == zone]

    line_info_dict = {'T1': t1_dict, 'T4': t4_dict, 'T6': t6_dict, 'T8': t8_dict, 'TX': tx_dict}

    return line_info_dict

def same_next_arr_batch_tm_gap(arr_time, next_batch, df_batch_san):
    next_batch_lat = df_batch_san[df_batch_san.arrive_batch == next_batch].batch_lat_tm.values[0]
    lat = ':'.join([next_batch_lat[0:2], next_batch_lat[2:4], '00'])
    consum = datetime.strptime(lat, '%H:%M:%S') - datetime.strptime(arr_time, '%H:%M:%S')
    if consum.total_seconds() < 0:
        consum = consum + timedelta(1)  # 跨日，则加一天
    consum = consum.total_seconds() / 60
    return consum

def same_find_next_san_batch(last_arr_code, arr_time, arr_sbatch_name, arr_sbatch_tm, df_batch_san):
    san_batch = df_batch_san[df_batch_san.hub_name == last_arr_code].arrive_batch.values
    if len(san_batch) == 0:
        return arr_sbatch_name, arr_sbatch_tm
    san_batch = np.array(sorted(san_batch, key=lambda x: x[-4:]))
    san_batch_start_tm = np.array([x[-4:] for x in san_batch])

    cur_batch_tm = arr_sbatch_name[-4:]
    next_batch = '0'
    if cur_batch_tm < '1700':
        index = np.argmax(san_batch_start_tm > cur_batch_tm)
        if index != 0:
            next_batch_tmp = san_batch[index]
            if next_batch_tmp[-4:] < '1700':
                next_batch = next_batch_tmp
    else:
        index = np.argmax(san_batch_start_tm > cur_batch_tm)
        next_batch_tmp = san_batch[index]
        if (cur_batch_tm < next_batch_tmp[-4:] < '2400') or (next_batch_tmp[-4:] < '1700'):
            next_batch = next_batch_tmp

    if next_batch != '0':
        arr_sbatch_tm = same_next_arr_batch_tm_gap(arr_time, next_batch, df_batch_san)
        arr_sbatch_name = next_batch

    return arr_sbatch_name, arr_sbatch_tm


## 始发与目的网点相同，匹配班次,计算耗时
def same_code_consum_tm(src_code, start_tm, product_type, important_city, df_batch_san, df_batch):
    src_city = re.match(r'\d+', src_code).group(0)
    if len(start_tm) == 5:
        start_tm = start_tm[0:2] + '00'
    elif len(start_tm) == 9:
        start_tm = start_tm[0:4]

    tmp_batch = df_batch_san[df_batch_san['hub_name'] == src_code]
    if len(tmp_batch) != 0:
        batch_name_tm = tmp_batch['arrive_batch'].values
        batch_lat_tm = tmp_batch['batch_lat_tm'].values
        index = np.argmax(batch_lat_tm >= start_tm)
        res_sbatch = batch_lat_tm[index]
        res_sbatch_name = batch_name_tm[index]
    else:
        res_sbatch = '0'
        res_sbatch_name = ''
        tmp_batch = df_batch[df_batch['hub_name'] == src_code]
        if len(tmp_batch) != 0:
            batch_lat_tm = tmp_batch['batch_lat_tm'].values
            batch_name_tm = tmp_batch['arrive_batch'].values
            index = np.argmax(batch_lat_tm >= start_tm)
            res_sbatch = batch_lat_tm[index]
            res_sbatch_name = batch_name_tm[index]

    if res_sbatch == '0':
        return 0, res_sbatch_name


    lat = ':'.join([res_sbatch[0:2], res_sbatch[2:4], '00'])
    arr = ':'.join([start_tm[0:2], start_tm[2:4], '00'])
    consum = datetime.strptime(lat, '%H:%M:%S') - datetime.strptime(arr, '%H:%M:%S')
    if consum.total_seconds() < 0:
        consum = consum + timedelta(1)  # 跨日，则加一天
    consum = consum.total_seconds() / 60

    important_city_label = not (src_city in important_city)
    if (product_type == 'T6') & (important_city_label):
        res_sbatch_name, consum = same_find_next_san_batch(src_code, arr, res_sbatch_name,
                                                             consum, df_batch_san)

    return consum, res_sbatch_name


def normal_jop_work(goal_od, line_info, df_batch_san, df_batch, important_city, process=0):
    res_od = []
    for index, od in enumerate(goal_od):
        display_progress(index, len(goal_od), process)
        temp_od = []
        src_code, dest_code, product_type, start_tm, *_ = od
        if src_code == dest_code:  # 始发与目的时只算囤货时长
            consm_tm, sbatch_name = same_code_consum_tm(src_code, start_tm, product_type, important_city,
                                                        df_batch_san, df_batch)
            fast_route = ('', consm_tm, sbatch_name)
        else:
            line_info_tmp = line_info[product_type]  # 相应产品的线路编码配载信息
            fast_route = search_fast_route(src_code, dest_code, product_type, start_tm, line_info_tmp,
                                           important_city, df_batch_san)
        temp_od.extend(od)
        temp_od.extend(fast_route)
        res_od.append(temp_od)

    return res_od


# if __name__ == "__main__":
#
#     # pymysql 直接创建连接引擎
#     conn = pymysql.connect(
#         host=DB_HOST_read,
#         port=3306,
#         user=DB_USER_read,
#         password=DB_PASS_read,
#         db=DATABASE_read,
#         charset='utf8'
#     )
#
#     line_date = '2019-05-18'
#     line_date_7 = datetime.strptime(line_date, "%Y-%m-%d") + timedelta(7)
#     line_date_7 = line_date_7.strftime('%Y-%m-%d')
#
#     # with open('goal_od_cff.pkl', 'rb') as f:
#     #     df_goal_od = pickle.load(f)
#     line_info, query_line = normal_get_line_config(conn, line_date, line_date_7)
#
#     # 关闭数据库连接
#     conn.close()
#
#     t1 = time.time()
#     # 开启的进程数, 与逻辑核保持一致即可，普通台式机建议30，高性能工作站建议200
#     proc_num = 1
#
# #     goal_ods = df_goal_od.values
#     goal_ods = [['512W', '510W', 'T4', '0000-0020']]
# #     goal_ods = [['755W', '020W', 'T4', '1100-1120']]
#     chunks_od = chunks(goal_ods, proc_num)
#     pool = Pool(processes=proc_num)
#     jop_result = []
#     for i, od_list in enumerate(chunks_od):
#         # 维持执行的进程总数为processes，当一个进程执行完毕后会添加新的进程进去
#         res = pool.apply_async(normal_jop_work, (od_list, line_info, query_line, i))
#         jop_result.append(res)
#
#     pool.close() #关闭进程池，防止进一步操作。如果所有操作持续挂起，它们将在工作进程终止前完成
#     pool.join()   #调用join之前，先调用close函数，否则会出错。执行完close后不会有新的进程加入到pool,join函数等待所有子进程结束
#
#     get_result = []
#     for tmp in jop_result:
#         get_result.extend(tmp.get()) #使用get来获取apply_aync的结果
#     t2 = time.time()
#     print(t2 - t1)
#     df = pd.DataFrame(get_result, columns=['src_hub', 'des_hub', 'product_type', 'start_time', 'fast_route', 'od_limit_time'])
#     df['od_limit_time'] = df['od_limit_time'] / 60
#     print(get_result)
#
#     with open('df_result1.pkl', 'wb') as f:
#         pickle.dump(df, f)

