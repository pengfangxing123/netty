import pandas as pd
import numpy as np
from datetime import datetime
from datetime import timedelta
import pymysql
import sqlalchemy
from sqlalchemy import create_engine
import pickle
import re

from normal_static_od_limit_tm.normal_route_consum_time import calc_static_tm


def next_arr_batch_tm_gap(arr_time, next_batch, df_batch_san):
    arr_time = arr_time.split(' ')[1]
    next_batch_lat = df_batch_san[df_batch_san.arrive_batch == next_batch].batch_lat_tm.values[0]
    lat = ':'.join([next_batch_lat[0:2], next_batch_lat[2:4], '00'])
    consum = datetime.strptime(lat, '%H:%M:%S') - datetime.strptime(arr_time, '%H:%M:%S')
    if consum.total_seconds() < 0:
        consum = consum + timedelta(1)  # 跨日，则加一天
    consum = consum.total_seconds() / 60
    return consum


def find_next_san_batch(last_arr_code, arr_time, arr_sbatch_name, arr_sbatch_tm, df_batch_san):
    san_batch = df_batch_san[df_batch_san.hub_name == last_arr_code].arrive_batch.values
    if len(san_batch) == 0:
        return arr_sbatch_name, arr_sbatch_tm
    san_batch = np.array(sorted(san_batch, key=lambda x: x[-4:]))
    san_batch_start_tm = np.array([x[-4:] for x in san_batch])

    cur_batch_tm = arr_sbatch_name[-4:]
    next_batch = '0'
    if cur_batch_tm < '1700':
        index = np.argmax(san_batch_start_tm > cur_batch_tm)
        if index != 0:
            next_batch_tmp = san_batch[index]
            if next_batch_tmp[-4:] < '1700':
                next_batch = next_batch_tmp
    else:
        index = np.argmax(san_batch_start_tm > cur_batch_tm)
        next_batch_tmp = san_batch[index]
        if (cur_batch_tm < next_batch_tmp[-4:] < '2400') or (next_batch_tmp[-4:] < '1700'):
            next_batch = next_batch_tmp

    if next_batch != '0':
        arr_sbatch_tm = next_arr_batch_tm_gap(arr_time, next_batch, df_batch_san)
        arr_sbatch_name = next_batch

    return arr_sbatch_name, arr_sbatch_tm


def limit_trans(tmp_list, next_src):
    # 限制同城只允许中转一次
    temp_city = [re.match(r'\d+', x).group() for x in tmp_list]
    temp_last_city = re.match(r'\d+', next_src).group()
    temp_city.append(temp_last_city)
    max_tran = pd.value_counts(temp_city).max()
    return max_tran


def search_fast_route(src_code, dest_code, product_type, start_tm, line_info, important_city, df_batch_san):
    MT = 9999  # 最快路由耗时初始值
    ans = []
    src_city = re.match(r'\d+', src_code).group(0)
    dest_city = re.match(r'\d+', dest_code).group(0)
    # 第一次 搜索始发网点为起始网点，带最终网点对应票件的线路编码
    fisrt_line_info = line_info.get(src_code, '0')
    if type(fisrt_line_info) == str:
        return ('', -60, '')
    search1 = fisrt_line_info[fisrt_line_info['total_city'].str.contains(dest_city)]
    first_cal_tm_line = search1
    result_search1 = list(set(search1.label.values))
    print('first_search_list:   ', result_search1)

    for rs1 in result_search1:
        print(rs1)
        temp_rs = '~'.join([rs1])
        temp_MT = calc_static_tm(temp_rs, start_tm, first_cal_tm_line)
        if temp_MT > MT:  # 如果大于已搜到的路由最优耗时，则跳出本层循环
            continue
        if rs1.split('-')[-1] == dest_code:
            MT = temp_MT
            ans.append((rs1, MT))
            continue

        # 第二次 搜索始发网点为第二段运力起始网点，带最终网点对应票件的线路编码
        src2 = rs1.split('-')[-1]
        second_line_info = line_info.get(src2, '0')
        if type(second_line_info) == str:
            continue
        search2 = second_line_info[second_line_info['total_city'].str.contains(dest_city)]
        second_cal_tm_line = pd.concat([search1, search2], ignore_index=True)
        result_search2 = list(set(search2.label.values))

        for rs2 in result_search2:
            temp_rs = '~'.join([rs1, rs2])
            temp_MT = calc_static_tm(temp_rs, start_tm, second_cal_tm_line)
            if temp_MT > MT:  # 如果大于已搜到的路由最优耗时，则跳出本层循环
                continue
            if rs2.split('-')[-1] == dest_code:
                MT = temp_MT
                ans.append((temp_rs, MT))
                continue

            src3 = rs2.split('-')[-1]
            temp_route = [rs1, rs2]
            max_tran = limit_trans(temp_route, src3)  # 限制同城中转次数
            if (max_tran > 2) or (src3 in [rs1.split('-')[0]]):  # 同城中转次数大于2,或出现迂回 跳出本次循环
                continue
            # 第三次 搜索始发网点为第三段运力起始网点，带最终网点对应票件的线路编码
            third_line_info = line_info.get(src3, '0')
            if type(third_line_info) == str:
                continue
            search3 = third_line_info[third_line_info['total_city'].str.contains(dest_city)]
            third_cal_tm_line = pd.concat([search1, search2, search3], ignore_index=True)
            result_search3 = list(set(search3.label.values))
            for rs3 in result_search3:
                temp_rs = '~'.join([rs1, rs2, rs3])
                temp_MT = calc_static_tm(temp_rs, start_tm, third_cal_tm_line)
                if temp_MT > MT:
                    continue
                if rs3.split('-')[-1] == dest_code:
                    MT = temp_MT
                    ans.append((temp_rs, MT))
                    continue

                src4 = rs3.split('-')[-1]
                temp_route = [rs1, rs2, rs3]
                max_tran = limit_trans(temp_route, src4)  # 限制同城中转次数
                if (max_tran > 2) or (src4 in [rs1.split('-')[0], rs2.split('-')[0]]):  # 同城中转次数大于2,或出现迂回 跳出本次循环
                    continue
                # 第4次 搜索始发网点为第4段运力起始网点，达到网点为最终网点，带最终网点对应票件的线路编码
                fourth_line_info = line_info.get(src4, '0')
                if type(fourth_line_info) == str:
                    continue
                search4 = fourth_line_info[(fourth_line_info.arrive_zone_code == dest_code) &
                                           (fourth_line_info['total_city'].str.contains(dest_city))]
                fourth_cal_tm_line = pd.concat([search1, search2, search3, search4], ignore_index=True)
                result_search4 = list(set(search4.label.values))
                for rs4 in result_search4:
                    temp_rs = '~'.join([rs1, rs2, rs3, rs4])
                    temp_MT = calc_static_tm(temp_rs, start_tm, fourth_cal_tm_line)
                    if temp_MT > MT:
                        continue
                    if rs4.split('-')[-1] == dest_code:
                        MT = temp_MT
                        ans.append((temp_rs, MT))
                        continue
    if ans:
        res = min(ans, key=lambda tm: (tm[1], len(tm[0])))  # 获取小路由耗时

        last_line = res[0].split('~')[-1]
        last_send_code = last_line.split('-')[0]
        last_line_code = last_line.split('-')[1]
        last_arr_code = last_line.split('-')[2]
        # 计划到车时间至所在散货（顺延）班次的计划最晚到车时间
        query_line_code = line_info[last_send_code]
        goal_query_line = query_line_code[(query_line_code['line_code'] == last_line_code) &
                                          (query_line_code['arrive_zone_code'] == last_arr_code)]
        arr_sbatch_tm = goal_query_line.add_batch_tm.values[0]
        arr_sbatch_name = goal_query_line.san_arrive_batch.values[0]
        arr_time = goal_query_line.plan_arrive_tm.values[0]

        important_city_label = not ((dest_city in important_city) & (src_city in important_city))
        if (product_type == 'T6') & (important_city_label):
            arr_sbatch_name, arr_sbatch_tm = find_next_san_batch(last_arr_code, arr_time, arr_sbatch_name,
                                                                 arr_sbatch_tm, df_batch_san)

        res = (res[0], res[1] + arr_sbatch_tm, arr_sbatch_name)
    else:
        res = ('', -60, '')

    return res
