import os
import pickle
import pymysql

# 缓存sql数据
def line_cache_func(cache_path, fn, *args, **kwargs):
    # If the cache-file exists.
    if os.path.exists(cache_path):
        # Load the cached data from the file.
        with open(cache_path, mode='rb') as file:
            obj = pickle.load(file)

        print("- 目标数据存在，缓存加载完毕: " + cache_path)
    else:
        # The cache-file does not exist.
        # Call the function / class-init with the supplied arguments.
        obj = fn(*args, **kwargs)

        # # Save the data to a cache-file.
        # with open(cache_path, mode='wb') as file:
        #     pickle.dump(obj, file)

        print("- 目标数据缓存存完毕: " + cache_path)
    return obj



# 显示进度
def display_progress(i, total, process=0):
    if i % 20 == 0:
        line = '=' * int((i/total) * 50)
        print(line + '=> process {0}:  {1}/{2}'.format(process, i, total))
# list分块
def chunks(list_data, seg_num):
    step = int(len(list_data) / seg_num)
    if step == 0:
        step = 1
    res = []
    for i in range(0, len(list_data), step):
        tmp = list_data[i:i+step]
        res.append(tmp)
    return res


def db_conn(DB_HOST, DB_USER, DB_PASS, DATABASE):
    # pymysql 直接创建连接引擎
    conn = pymysql.connect(
        host=DB_HOST,
        port=3306,
        user=DB_USER,
        password=DB_PASS,
        db=DATABASE,
        charset='utf8'
    )

    return conn


def db_close(conn):
    # pymysql 关闭数据库连接
    conn.close()

