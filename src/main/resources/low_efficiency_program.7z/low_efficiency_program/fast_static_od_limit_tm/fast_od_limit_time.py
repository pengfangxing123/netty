import configparser
from multiprocessing import Process, Pool
import time
from datetime import datetime
from datetime import timedelta
import pandas as pd
import numpy as np
import pymysql
import sqlalchemy
from sqlalchemy import create_engine
import pickle
import re
import os
import sys

sys.path.append(os.path.abspath('.'))

from fast_static_od_limit_tm.fast_link_route import search_fast_route
from fast_static_od_limit_tm.fast_line_code_base_info import generate_line_info
from util.common_util import *

# DB_USER_read = 'ornp'
# DB_PASS_read = 'fiblGb6vuw'
# DB_HOST_read = 'ornp-m.dbsit.sfdc.com.cn'
# DB_PORT_read = '3306'
# DATABASE_read = 'ornp'


conf = configparser.ConfigParser()
root_dir = os.getcwd()  # 获取当前文件所在目录的上一级目录，即项目所在目录E:\Crawler
configpath = os.path.join(root_dir, 'config_data', "low_efficiency_config.ini")
conf.read(configpath)

DB_USER_read = conf.get("Mysql", "DB_USER_read")
DB_PASS_read = conf.get("Mysql", "DB_PASS_read")
DB_HOST_read = conf.get("Mysql", "DB_HOST_read")
DB_PORT_read = conf.get("Mysql", "DB_PORT_read")
DATABASE_read = conf.get("Mysql", "DATABASE_read")


# 读取线路配置信息
def fast_get_line_config(conn, line_date):
    line_info_name = 'low_efficiency_line_info_' + line_date + '.pkl'
    line_info_all = line_cache_func(line_info_name, generate_line_info, conn_pymysql=conn)

    # 为了减少查询量，简单的将不同产品分开
    # line_info_T1 = line_info_all[line_info_all['product'].str.contains('T1')].copy()
    # line_info_T4 = line_info_all[line_info_all['product'].str.contains('T4')].copy()
    # line_info_T6 = line_info_all[line_info_all['product'].str.contains('T6')].copy()
    # line_info_T8 = line_info_all[line_info_all['product'].str.contains('T8')].copy()

    line_info_T1 = line_info_all
    line_info_T4 = line_info_all
    line_info_T6 = line_info_all
    line_info_T8 = line_info_all

    t1_send_zone = line_info_T1.send_zone_code.unique()
    t1_dict = {}
    for zone in t1_send_zone:
        t1_dict[zone] = line_info_T1[line_info_T1.send_zone_code == zone]

    t4_send_zone = line_info_T4.send_zone_code.unique()
    t4_dict = {}
    for zone in t4_send_zone:
        t4_dict[zone] = line_info_T4[line_info_T4.send_zone_code == zone]

    t6_send_zone = line_info_T6.send_zone_code.unique()
    t6_dict = {}
    for zone in t6_send_zone:
        t6_dict[zone] = line_info_T6[line_info_T6.send_zone_code == zone]

    t8_send_zone = line_info_T8.send_zone_code.unique()
    t8_dict = {}
    for zone in t8_send_zone:
        t8_dict[zone] = line_info_T8[line_info_T8.send_zone_code == zone]

    line_info_dict = {'T1': t1_dict, 'T4': t4_dict, 'T6': t6_dict, 'T8': t8_dict}

    return line_info_dict


# 始发与目的网点相同，匹配班次,计算耗时
def same_code_consum_tm(src_code, start_tm, df_batch_san, df_batch):
    if len(start_tm) == 5:
        start_tm = start_tm[0:2] + '00'
    elif len(start_tm) == 9:
        start_tm = start_tm[0:4]

    tmp_batch = df_batch_san[df_batch_san['hub_name'] == src_code]
    if len(tmp_batch) != 0:
        batch_name_tm = tmp_batch['arrive_batch'].values
        batch_lat_tm = tmp_batch['batch_lat_tm'].values
        index = np.argmax(batch_lat_tm >= start_tm)
        res_sbatch = batch_lat_tm[index]
        res_sbatch_name = batch_name_tm[index]
    else:
        res_sbatch = '0'
        res_sbatch_name = ''
        tmp_batch = df_batch[df_batch['hub_name'] == src_code]
        if len(tmp_batch) != 0:
            batch_lat_tm = tmp_batch['batch_lat_tm'].values
            batch_name_tm = tmp_batch['arrive_batch'].values
            index = np.argmax(batch_lat_tm >= start_tm)
            res_sbatch = batch_lat_tm[index]
            res_sbatch_name = batch_name_tm[index]

    if res_sbatch == '0':
        return 0, res_sbatch_name

    lat = ':'.join([res_sbatch[0:2], res_sbatch[2:4], '00'])
    arr = ':'.join([start_tm[0:2], start_tm[2:4], '00'])
    consum = datetime.strptime(lat, '%H:%M:%S') - datetime.strptime(arr, '%H:%M:%S')
    if consum.total_seconds() < 0:
        consum = consum + timedelta(1)  # 跨日，则加一天
    consum = consum.total_seconds() / 60

    return consum, res_sbatch_name


def fast_jop_work(goal_od, line_info_dict, df_batch_san, df_batch, process=0):
    res_od = []
    for index, od in enumerate(goal_od):
        display_progress(index, len(goal_od), process)
        temp_od = []
        src_code, dest_code, product_type, start_tm, *_ = od
        if src_code == dest_code:  # 始发与目的时只算囤货时长
            consm_tm, sbatch_name = same_code_consum_tm(src_code, start_tm, df_batch_san, df_batch)
            fast_route = ('', consm_tm, sbatch_name)
        else:
            line_info_tmp = line_info_dict[product_type]  # 相应产品的线路编码配载信息
            fast_route = search_fast_route(src_code, dest_code, product_type, start_tm, line_info_tmp)
        temp_od.extend(od)
        temp_od.extend(fast_route)
        res_od.append(temp_od)

    return res_od

#
# if __name__ == "__main__":
#
#
#     conn = db_conn() # 连接数库
#     line_date = datetime.strftime(datetime.now(), '%Y-%m-%d')  # 此值为缓存线路配置信息而设置，但此模块缓存模块已被注释，若不开启，无需改变
#
#     line_info, query_line = get_line_config(conn, line_date)  # 线路编码配置信息
#     db_close(conn) # 关闭数据库连接
#
#     t1 = time.time()
#     # 开启的进程数, 与逻辑核保持一致即可，普通台式机建议80，高性能工作站建议200
#     proc_num = 1
#     goal_ods = [['020W', '769WB', 'T1', '1200-1220']]
#     chunks_od = chunks(goal_ods, proc_num) # od数据分块
#     pool = Pool(processes=proc_num) # 进程池
#     jop_result = []
#     for i, od_list in enumerate(chunks_od):
#         # 维持执行的进程总数为processes，当一个进程执行完毕后会添加新的进程进去
#         res = pool.apply_async(jop_work, (od_list, line_info, query_line, i))
#         jop_result.append(res)
#
#     pool.close() #关闭进程池，防止进一步操作。如果所有操作持续挂起，它们将在工作进程终止前完成
#     pool.join()   #调用join之前，先调用close函数，否则会出错。执行完close后不会有新的进程加入到pool,join函数等待所有子进程结束
#
#     get_result = []
#     for tmp in jop_result:
#         get_result.extend(tmp.get()) #使用get来获取apply_aync的结果
#
#     t2 = time.time()
#     print(t2 - t1)
#     # 结果转换为dataframe形式，便于分析
#     df = pd.DataFrame(get_result, columns=['src_hub', 'des_hub', 'product_type', 'start_time', 'fast_route', 'od_limit_time'])
#     df['od_limit_time'] = df['od_limit_time'] / 60
#     df['od_limit_time'] = round(df.od_limit_time, 3)
#
#     # 缓存结果文件，以备分析结果
#     with open('df_od_limit_time_lr.pkl', 'wb') as f:
#         pickle.dump(df, f)
