import pandas as pd
from datetime import datetime
from datetime import timedelta
import pymysql
import sqlalchemy
from sqlalchemy import create_engine
import pickle
import re


def calc_line_time(start_tm, end_tm):
    delt = datetime.strptime(end_tm, '%Y-%m-%d %H:%M:%S') - datetime.strptime(start_tm, '%Y-%m-%d %H:%M:%S')
    delt = delt.total_seconds() / 60
    return delt

# 计算到车时间至下一段运力最晚到车时间的时间间隔
def calc_gap_time(arrive_tm, lastest_arrive_tm):
    arrive_tm = arrive_tm.split(' ')[1]
    lastest_arrive_tm = lastest_arrive_tm.split(' ')[1]
    delt = datetime.strptime(lastest_arrive_tm, '%H:%M:%S') - datetime.strptime(arrive_tm, '%H:%M:%S')
    if delt.total_seconds() < 0:
        delt = delt + timedelta(1)  # 在最晚到达时间后到达，则推后一天
    delt = delt.total_seconds() / 60
    return delt


# 一段线路编码的耗时
def calc_tolal_line_time(src_label, line_code, send_code, arrive_code, next_code, prev_arrive_tm, query_line_code):
    # 查找相应的线路配置信息
    goal_line_stop = ((query_line_code.line_code == line_code) &
                      (query_line_code.send_zone_code == send_code) &
                      (query_line_code.arrive_zone_code == arrive_code))
    # 查找相应的线路配置信息，到达网点为线路编码中的代码
    src_code, dest_code = re.findall(r'\d+[A-Z]+', line_code)
    goal_line = ((query_line_code.line_code == line_code) &
                 (query_line_code.send_zone_code == src_code) &
                 (query_line_code.arrive_zone_code == dest_code))

    goal_line_base = (query_line_code.line_code == line_code)

    if (sum(goal_line_base) == 0) or (prev_arrive_tm == 'line_code_not_find'):
        return 1000000  # 如果线路编码找不到， 则用一个大值替代，最后结果统一处理

    if src_label == 0:
        # 如果为第一个始发网点
        if ((next_code in line_code) & (send_code in line_code)) | (sum(goal_line_stop) == 0):  # 找不到经停时间, 则用goal_line代替
            goal_line_temp = query_line_code[goal_line]
            last_tm = goal_line_temp.lastest_arrive_tm.values[0] if len(goal_line_temp) != 0 else query_line_code[goal_line_base].lastest_arrive_tm.values[0]
            arrive_tm = goal_line_temp.plan_arrive_tm.values[0] if len(goal_line_temp) != 0 else query_line_code[goal_line_base].plan_arrive_tm.values[0]
        else:
            last_tm = query_line_code[goal_line_stop].lastest_arrive_tm.values[0]
            arrive_tm = query_line_code[goal_line_stop].plan_arrive_tm.values[0]
        gap_time = 0
        line_time = calc_line_time(last_tm, arrive_tm) # 最晚到车时间至到车时间
    else:
        if ((next_code in line_code) & (send_code in line_code)) | (sum(goal_line_stop) == 0):  # 找不到经停时间, 则用goal_line代替
            goal_line_temp = query_line_code[goal_line]
            last_tm = goal_line_temp.lastest_arrive_tm.values[0] if len(goal_line_temp) != 0 else query_line_code[goal_line_base].lastest_arrive_tm.values[0]
            arrive_tm = goal_line_temp.plan_arrive_tm.values[0] if len(goal_line_temp) != 0 else query_line_code[goal_line_base].plan_arrive_tm.values[0] 
        else:
            last_tm = query_line_code[goal_line_stop].lastest_arrive_tm.values[0]
            arrive_tm = query_line_code[goal_line_stop].plan_arrive_tm.values[0]

        gap_time = calc_gap_time(prev_arrive_tm, last_tm)  # 前段运力的到车时间至当前运力的最晚到车时间
        line_time = calc_line_time(last_tm, arrive_tm)  # 最晚到车时间至到车时间

    result = gap_time + line_time # 前段运力的到车时间至当前运力的到车时间

    return result


def find_prev_arrive_time(line_code, arrive_code, query_line_code):
    # 查找相应的线路配置信息
    goal_line_stop = ((query_line_code.line_code == line_code) &
                      (query_line_code.arrive_zone_code == arrive_code))
    # 查找相应的线路配置信息，到达网点为线路编码中的代码
    src_code, dest_code = re.findall(r'\d+[A-Z]+', line_code)
    goal_line = ((query_line_code.line_code == line_code) &
                 (query_line_code.arrive_zone_code == dest_code))

    goal_line_base = (query_line_code.line_code == line_code)
    if sum(goal_line_base) == 0:
        return 'line_code_not_find'  # 线路编码找不到
    
    # 查找到达时间
    if (arrive_code in line_code) | (sum(goal_line_stop) == 0):
        goal_line_temp = query_line_code[goal_line]
        arrive_tm = goal_line_temp.plan_arrive_tm.values[0] if len(goal_line_temp) != 0 else query_line_code[goal_line_base].plan_arrive_tm.values[0]
    else:
        arrive_tm = query_line_code[goal_line_stop].plan_arrive_tm.values[0]

    return arrive_tm



# 路由耗时时间
def route_time(clean_route, query_line_code):
    src_line_dest = clean_route.split('~')
    toal_time = 0
    for i, code in enumerate(src_line_dest):

        send_code, line_code, arrive_code = code.split('-')

        if i == (len(src_line_dest) - 1):
            next_code = 'last_line'
        else:
            next_code = src_line_dest[i + 1].split('-')[0]

        if i == 0:
            prev_arrive_tm = 'first_gap_time'
        else:
            prev_line = src_line_dest[i - 1].split('-')[1]
            prev_arrive_tm = find_prev_arrive_time(prev_line, send_code, query_line_code)

        sub_time = calc_tolal_line_time(i, line_code, send_code, arrive_code, next_code, prev_arrive_tm, query_line_code)
        toal_time += sub_time

    return toal_time


# 车辆到达至第一个网点最晚到达开始的时间 0040-0059
def arr_send_tm(start_time, last_time):
    if len(start_time) == 4: # 判断时间格式
        arr = ':'.join([start_time[0:2], start_time[2:4], '00'])
    elif len(start_time) == 5:
        arr = ':'.join([start_time[0:2], '00', '00'])
    else:
        arr = ':'.join([start_time[0:2], start_time[2:4], '00'])
    lat = last_time.split(' ')[1]
    consum = datetime.strptime(lat, '%H:%M:%S') - datetime.strptime(arr, '%H:%M:%S')
    if consum.total_seconds() < 0:  # 如果在最晚到达时间后到达，则推后一天
        consum = consum + timedelta(1)
    consum = consum.total_seconds() / 60

    return consum


# 静态路由的耗时
def calc_static_tm(route, start_tm, query_line_code):
    first_line_code = route.split('~')[0]
    first_send = first_line_code.split('-')[0]
    first_line = first_line_code.split('-')[1]
    first_arr = first_line_code.split('-')[2]
    goal_line = ((query_line_code.line_code == first_line) &
                 (query_line_code.send_zone_code == first_send) &
                 (query_line_code.arrive_zone_code == first_arr))
    try:
        first_last_tm = query_line_code[goal_line].lastest_arrive_tm.values[0]
        # 到达第一个网点至最晚发车时间
    except Exception as e:
        print(e)
        raise Exception("6666666666666666666666")
    t1 = arr_send_tm(start_tm, first_last_tm)
    # 第一个网点最晚发车时间至最终网点的到车时间
    t2 = route_time(route, query_line_code)

    res = t1 + t2

    return res





