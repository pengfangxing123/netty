import pandas as pd
from datetime import datetime
from datetime import timedelta
import pymysql
import sqlalchemy
from sqlalchemy import create_engine
import pickle
import re


def regular_cargo(cargo):
    cargo_list = cargo.split(',')
    t1, t4, t6, t8 = [], [], [], []
    for item in cargo_list:
        if item[0:2] == 'T1':
            t1.append(item[3:])
        elif item[0:2] == 'T4':
            t4.append(item[3:])
        elif item[0:2] == 'T6':
            t6.append(item[3:])
        else:
            t8.append(item[3:])

    res_all = ''
    if t1:
        t1_res = 'T1:' + ','.join(t1)
        res_all = res_all + t1_res
    if t4:
        t4_res = '~T4:' + ','.join(t4)
        res_all = res_all + t4_res
    if t6:
        t6_res = '~T6:' + ','.join(t6)
        res_all = res_all + t6_res
    if t8:
        t8_res = '~T8:' + ','.join(t8)
        res_all = res_all + t8_res

    res_all = res_all.strip("~")
    return res_all

def read_origin_line(conn_pymysql):

    sql1 = "SELECT * FROM ops_mlo_d_line_alter_sum"
    move_route = pd.read_sql(sql=sql1, con=conn_pymysql)

    move_route = move_route[['line_code', 'cargo_city', 'pass_mode', 'src_dept_code', 'dest_dept_code', 'lastest_arrive_tm',
             'plan_arrive_tm', 'plan_send_batch', 'plan_arrive_batch']]
    move_route = move_route.drop_duplicates(['line_code', 'src_dept_code', 'dest_dept_code'])

    move_route = move_route[
        ~((move_route.lastest_arrive_tm.isnull()) | (move_route.plan_arrive_tm.isnull()))]  # 去除计划发车到达为空值的记录
    move_route = move_route[~((move_route.src_dept_code.isnull()) | (move_route.dest_dept_code.isnull()))]
    # 将配载信息全为空的删除掉
    move_route = move_route[~(move_route.cargo_city.isnull())]

    move_route['reg_cargo'] = move_route['cargo_city'].apply(regular_cargo)
    move_route = move_route.drop('reg_cargo', axis=1).join(
        move_route['reg_cargo'].str.split('~', expand=True).stack().reset_index(level=1, drop=True).rename('reg_cargo'))
    move_route['product'], move_route['total_city'] = move_route['reg_cargo'].str.split(':', 1).str

    move_route = move_route[['line_code', 'src_dept_code', 'dest_dept_code', 'lastest_arrive_tm', 'plan_arrive_tm', 'plan_send_batch',
             'plan_arrive_batch', 'product', 'total_city']]
    move_route = move_route.rename(columns={'src_dept_code': 'send_zone_code', 'dest_dept_code': 'arrive_zone_code'})
    move_route = move_route[['line_code', 'send_zone_code', 'arrive_zone_code', 'lastest_arrive_tm',
             'plan_arrive_tm', 'plan_send_batch', 'plan_arrive_batch', 'product', 'total_city']]
    move_route['label'] = move_route['send_zone_code'] + '-' + move_route['line_code'] + '-' + move_route['arrive_zone_code']
    return move_route


def generate_line_info(conn_pymysql):

    move_route = read_origin_line(conn_pymysql)

    return move_route





