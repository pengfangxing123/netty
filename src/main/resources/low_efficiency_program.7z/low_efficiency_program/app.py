from multiprocessing import Process, Pool
from datetime import datetime
from datetime import timedelta
import configparser
import pandas as pd
import pickle
import re
import os

from flask import Flask, request, jsonify, render_template
import json

from normal_static_od_limit_tm.normal_od_limit_time import normal_get_line_config, get_important_city, normal_jop_work
from fast_static_od_limit_tm.fast_od_limit_time import fast_get_line_config, fast_jop_work
from util.log import get_log
from util.common_util import *

conf = configparser.ConfigParser()
root_dir = os.getcwd()
configpath = os.path.join(root_dir, 'config_data', "low_efficiency_config.ini")
conf.read(configpath)

DB_USER_read = conf.get("Mysql", "DB_USER_read")
DB_PASS_read = conf.get("Mysql", "DB_PASS_read")
DB_HOST_read = conf.get("Mysql", "DB_HOST_read")
DB_PORT_read = conf.get("Mysql", "DB_PORT_read")
DATABASE_read = conf.get("Mysql", "DATABASE_read")

root_dir = os.path.abspath('.')
log_file = os.path.join(root_dir, 'log', "low_efficiency.log")
logger = get_log('low_efficiency', log_file)  # 添加日志

app = Flask(__name__)


# 返回最快路由数据
@app.route('/fast-route', methods=['GET', 'POST'])
def fast_route():
    global fast_line_info  # 声明全局变量
    global fast_verson_num

    if request.method == 'POST':
        re_data = request.get_data()
        od = json.loads(re_data)

        if fast_verson_num != od['version']:
            fast_verson_num = od['version']
            conn = db_conn(DB_HOST_read, DB_USER_read, DB_PASS_read, DATABASE_read)
            logger.info('加载最快路由池数据, 版本号：' + fast_verson_num)
            fast_line_info = fast_get_line_config(conn, fast_verson_num)  # 线路编码配置信息
            db_close(conn)  # 关闭数据库连接

        goal_ods = [[od['sendZoneCode'], od['arriveZoneCode'], od['productType'], od['startTime']]]
        try:
            res = fast_jop_work(goal_ods, fast_line_info, df_batch_san, df_batch, 1)
            data = {"odLimitTime": round(res[0][5] / 60, 2), "route": res[0][4], "arriveBatch": res[0][6]}
        except:
            logger.error(goal_ods)
            logger.error('fast-route Bug', exc_info=True)
            raise Exception('fast_route bug....')
        print(goal_ods)
        print(data)
        return jsonify(data), 201
    else:
        sendZoneCode = request.args.get("src")
        arriveZoneCode = request.args.get("dest")
        productType = request.args.get("pt")
        startTime = request.args.get("st")

        goal_ods = [[sendZoneCode, arriveZoneCode, productType, startTime]]
        res = fast_jop_work(goal_ods, fast_line_info, df_batch_san, df_batch, 1)
        data = {"odLimitTime": round(res[0][5] / 60, 2), "route": res[0][4], "arriveBatch": res[0][6]}
        return jsonify(data), 201


# 返回标准耗时数据
@app.route('/normal-time', methods=['GET', 'POST'])
def normal_time():
    global normal_line_info  # 声明全局变量
    global normal_verson_num
    global df_batch
    global df_batch_san
    if request.method == 'POST':
        re_data = request.get_data()
        od = json.loads(re_data)

        if normal_verson_num != od['version']:
            normal_verson_num = od['version']
            conn = db_conn(DB_HOST_read, DB_USER_read, DB_PASS_read, DATABASE_read)
            logger.info('加载标准路由池数据, 版本号：' + normal_verson_num)
            normal_line_info = normal_get_line_config(conn, normal_verson_num)
            db_close(conn)  # 关闭数据库连接
            with open(df_batch_path, 'rb') as f:
                df_batch = pickle.load(f)
            with open(df_batch_san_path, 'rb') as f:
                df_batch_san = pickle.load(f)

        goal_ods = [[od['sendZoneCode'], od['arriveZoneCode'], od['productType'], od['startTime']]]
        try:
            res = normal_jop_work(goal_ods, normal_line_info, df_batch_san, df_batch, important_city, 1)
            data = {"odLimitTime": round(res[0][5] / 60, 2), "route": res[0][4], "arriveBatch": res[0][6]}
        except:
            logger.error(goal_ods)
            logger.error('normal-route Bug', exc_info=True)
            raise Exception('normal-time bug....')
        print(goal_ods)
        print(data)
        return jsonify(data), 201
    else:
        sendZoneCode = request.args.get("src")
        arriveZoneCode = request.args.get("dest")
        productType = request.args.get("pt")
        startTime = request.args.get("st")

        goal_ods = [[sendZoneCode, arriveZoneCode, productType, startTime]]
        res = normal_jop_work(goal_ods, normal_line_info, df_batch_san, df_batch, important_city, 1)
        data = {"odLimitTime": round(res[0][5] / 60, 2), "route": res[0][4], "arriveBatch": res[0][6]}
        return jsonify(data), 201


# # 测试演示
# @app.route('/')
# def index():
#     return render_template('fast_route_od_limit_tm.html')
#
# @app.route('/od_limit_time', methods=['post'])
# def odLimitTime():
#     sendZoneCode = request.form['send_zone']
#     arriveZoneCode = request.form['arr_zone']
#     productType = request.form['product_type']
#     startTime = request.form['start_time']
#     if sendZoneCode != '' and arriveZoneCode != '' and productType != '' and startTime != '':
#         goal_ods = [[sendZoneCode, arriveZoneCode, productType, startTime]]
#         res = normal_jop_work(goal_ods, normal_line_info, df_batch_san, df_batch, important_city, 1)
#         data = {"odLimitTime": round(res[0][5] / 60, 2), "route": res[0][4], "arriveBatch": res[0][6]}
#         print(goal_ods)
#         print(data)
#         return render_template('fast_route_od_limit_tm.html', res=data, send_zone=sendZoneCode, arr_zone=arriveZoneCode,
#                                product_type=productType, start_time=startTime)
#     return render_template('fast_route_od_limit_tm.html')


if __name__ == '__main__':
    logger.info('初始化数据中......')
    normal_verson_num = '20190101'  # 启动初始版本号
    fast_verson_num = '20190101'  # 启动初始版本号

    conn = db_conn(DB_HOST_read, DB_USER_read, DB_PASS_read, DATABASE_read)
    normal_line_info = normal_get_line_config(conn, normal_verson_num)
    important_city = get_important_city(conn)
    db_close(conn)  # 关闭数据库连接
    # 加载班次信息
    df_batch_path = os.path.join(root_dir, 'config_data', 'df_batch.pkl')
    df_batch_san_path = os.path.join(root_dir, 'config_data', 'df_batch_san.pkl')
    with open(df_batch_path, 'rb') as f:
        df_batch = pickle.load(f)
    with open(df_batch_san_path, 'rb') as f:
        df_batch_san = pickle.load(f)
    logger.info('初始化数据完成')
    # app.run(host='127.0.0.1', port=8089)
    app.run(port=8089)
